import streamlit as st
import numpy as np
import pandas as pd
import joblib
import os
import plotly.graph_objects as go
import plotly.express as px

# ---------------- CONFIG ---------------- #

st.set_page_config(
page_title="AI Diabetes Risk System",
page_icon="🩺",
layout="wide"
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ---------------- CUSTOM CSS ---------------- #

st.markdown("""
<style>

.main{
background-color:#f7fbff;
}

.stButton>button{
background-color:#0b5ed7;
color:white;
border-radius:10px;
height:3em;
width:100%;
font-size:18px;
}

.metric-card{
padding:20px;
border-radius:15px;
background:white;
box-shadow:0px 4px 12px rgba(0,0,0,0.1);
}

.risk-low{
background:#e8f8f0;
padding:15px;
border-radius:10px;
}

.risk-mid{
background:#fff4e6;
padding:15px;
border-radius:10px;
}

.risk-high{
background:#fdecea;
padding:15px;
border-radius:10px;
}

</style>
""",unsafe_allow_html=True)

# ---------------- HEADER ---------------- #

st.title("🩺 AI Diabetes Risk Prediction System")

st.markdown("""
### Preventive Healthcare using Machine Learning ❤️📊🧠🏥
""")

st.divider()

# ---------------- LOAD MODELS ---------------- #

@st.cache_resource
def load_models():

    model = joblib.load(os.path.join(BASE_DIR,"models","diabetes_model1.pkl"))

    scaler = joblib.load(os.path.join(BASE_DIR,"models","scaler2.pkl"))

    features = joblib.load(os.path.join(BASE_DIR,"models","features3.pkl"))

    threshold = joblib.load(os.path.join(BASE_DIR,"models","threshold4.pkl"))

    importance = pd.read_csv(
        os.path.join(BASE_DIR,"models","feature_importance5.csv")
    )

    return model,scaler,features,threshold,importance


model,scaler,features,threshold,importance = load_models()

# ---------------- SESSION STATE ---------------- #

if "prob" not in st.session_state:
    st.session_state.prob=None

if "prediction_done" not in st.session_state:
    st.session_state.prediction_done=False

# ---------------- TABS ---------------- #

tab1,tab2,tab3,tab4 = st.tabs([

"🧾 Prediction",

"📊 Analytics",

"📈 Model Insights",

"ℹ About"

])

# ---------------- SIDEBAR ---------------- #

st.sidebar.title("👤 Patient Form")

Age = st.sidebar.slider("Age",18,100,30)

Sex = st.sidebar.selectbox("Sex",["Female","Male"])
Sex = 1 if Sex=="Male" else 0

BMI = st.sidebar.number_input("BMI",15.0,60.0,25.0)

HighBP = st.sidebar.selectbox("High Blood Pressure",["No","Yes"])
HighBP = 1 if HighBP=="Yes" else 0

HighChol = st.sidebar.selectbox("High Cholesterol",["No","Yes"])
HighChol = 1 if HighChol=="Yes" else 0

Smoker = st.sidebar.selectbox("Smoker",["No","Yes"])
Smoker = 1 if Smoker=="Yes" else 0

PhysActivity = st.sidebar.selectbox("Physical Activity",["No","Yes"])
PhysActivity = 1 if PhysActivity=="Yes" else 0

Fruits = st.sidebar.selectbox("Eats Fruits",["No","Yes"])
Fruits = 1 if Fruits=="Yes" else 0

Veggies = st.sidebar.selectbox("Eats Vegetables",["No","Yes"])
Veggies = 1 if Veggies=="Yes" else 0

HvyAlcoholConsump = st.sidebar.selectbox("Heavy Alcohol Consumption",["No","Yes"])
HvyAlcoholConsump = 1 if HvyAlcoholConsump=="no" else 0

HeartDiseaseorAttack = st.sidebar.selectbox("Heart Disease History",["No","Yes"])
HeartDiseaseorAttack = 1 if HeartDiseaseorAttack=="no" else 0

Stroke = st.sidebar.selectbox("Stroke History",["No","Yes"])
Stroke = 1 if Stroke=="no" else 0

AnyHealthcare = st.sidebar.selectbox("Has Healthcare Access",["No","Yes"])
AnyHealthcare = 1 if AnyHealthcare=="Yes" else 0

NoDocbcCost = st.sidebar.selectbox("Could not visit doctor due to cost",["No","Yes"])
NoDocbcCost = 1 if NoDocbcCost=="no" else 0

GenHlth = st.sidebar.slider("General Health (1=Excellent,5=Poor)",1,5,3)

MentHlth = st.sidebar.slider("Mental Health Days",0,30,0)

PhysHlth = st.sidebar.slider("Physical Health Days",0,30,0)

DiffWalk = st.sidebar.selectbox("Difficulty Walking",["No","Yes"])
DiffWalk = 1 if DiffWalk=="Yes" else 0

Education = st.sidebar.slider("Education Level",1,6,3)

Income = st.sidebar.slider("Income Level",1,8,4)

# ---------------- FEATURE ENGINEERING ---------------- #

BMI_Category = 0

if BMI<18.5:
    BMI_Category=0

elif BMI<25:
    BMI_Category=1

elif BMI<30:
    BMI_Category=2

else:
    BMI_Category=3


Age_Group = 0

if Age<30:
    Age_Group=0

elif Age<100:
    Age_Group=1

else:
    Age_Group=2


BMI_PhysActivity = BMI*PhysActivity


# ---------------- RULE ENGINE ---------------- #

def evaluate_lifestyle(data):

    score = 0
    reasons = []

    bad_habits = data['Smoker'] + data['HvyAlcoholConsump'] + (1-data['PhysActivity'])

    if bad_habits >=2:
        score += 15
        reasons.append("Multiple unhealthy lifestyle habits increasing risk")

    if data['PhysActivity']==1 and data['Fruits']==1 and data['Veggies']==1:
        score -= 10
        reasons.append("Healthy lifestyle reducing risk")

    if data['BMI']>30 and data['PhysActivity']==0:
        score +=20
        reasons.append("High BMI with no activity increases risk")

    return score,reasons


def evaluate_medical(data):

    score=0
    reasons=[]

    chronic = data['HighBP'] + data['HighChol'] + data['HeartDiseaseorAttack']

    if chronic>=2:
        score+=18
        reasons.append("Multiple chronic conditions detected")

    if data['GenHlth']>=4 and data['PhysHlth']>10:
        score+=15
        reasons.append("Poor general and physical health")

    if data['Stroke']==1 and data['HighBP']==1:
        score+=12
        reasons.append("Stroke history with BP risk")

    return score,reasons


def evaluate_socioeconomic(data):

    score=0
    reasons=[]

    if data['Income']<=3 and data['AnyHealthcare']==0:
        score+=14
        reasons.append("Low income and no healthcare access")

    if data['NoDocbcCost']==1:
        score+=8
        reasons.append("Unable to afford doctor visits")

    if data['Education']>=5:
        score-=5
        reasons.append("Higher education slightly protective")

    return score,reasons


def evaluate_interactions(data):

    score=0
    reasons=[]

    if data['Age']>50 and data['PhysActivity']==1:
        score-=6
        reasons.append("Physical activity offsets age risk")

    if data['Age']<35 and data['Smoker']==1 and data['PhysActivity']==0:
        score+=16
        reasons.append("Young but high-risk lifestyle")

    if data['MentHlth']>15 and data['PhysHlth']>15:
        score+=14
        reasons.append("Mental and physical stress interaction")

    if data['BMI']>28 and data['Smoker']==1:
        score+=10
        reasons.append("Smoking amplifies BMI risk")

    return score,reasons


def normalize_rule_score(score):

    score = max(-50,min(score,50))

    prob = (score+50)/100

    return prob


def run_rule_engine(data):

    total_score=0

    explanations=[]

    s1,r1 = evaluate_lifestyle(data)
    s2,r2 = evaluate_medical(data)
    s3,r3 = evaluate_socioeconomic(data)
    s4,r4 = evaluate_interactions(data)

    total_score = s1+s2+s3+s4

    explanations = r1+r2+r3+r4

    rule_prob = normalize_rule_score(total_score)

    return total_score,rule_prob,explanations


# ================= [POINT 3] HEALTH + SEVERITY ================= #

def calculate_health_score(data):

    score = 100

    if data['HighBP']==1: score -=10
    if data['HighChol']==1: score -=10
    if data['Smoker']==1: score -=15
    if data['BMI']>30: score -=15
    if data['PhysActivity']==0: score -=15
    if data['Fruits']==0: score -=5
    if data['Veggies']==0: score -=5
    if data['HvyAlcoholConsump']==1: score -=10
    if data['GenHlth']>=4: score -=10

    return max(0,score)


def medical_severity(data):

    severity=0

    severity += data['HighBP']*2
    severity += data['HighChol']*2
    severity += data['HeartDiseaseorAttack']*3
    severity += data['Stroke']*3
    severity += data['DiffWalk']*2

    if data['BMI']>30: severity+=2
    if data['GenHlth']>=4: severity+=2

    return severity


def personalized_drivers(data):

    drivers=[]

    if data['BMI']>30: drivers.append(("BMI","High impact"))
    if data['HighBP']==1: drivers.append(("Blood Pressure","Major risk"))
    if data['HighChol']==1: drivers.append(("Cholesterol","Major risk"))
    if data['PhysActivity']==0: drivers.append(("Physical inactivity","Lifestyle risk"))
    if data['Smoker']==1: drivers.append(("Smoking","Behavior risk"))
    if data['GenHlth']>=4: drivers.append(("General health","Clinical concern"))
    if data['MentHlth']>15: drivers.append(("Mental stress","Moderate factor"))

    return drivers

# ---------------- TAB 1 PREDICTION ---------------- #

with tab1:

    if st.button("🔍 Predict Risk"):

        with st.spinner("Analyzing patient health..."):

            input_df = pd.DataFrame([{

'HighBP':HighBP,
'HighChol':HighChol,
'CholCheck':1,
'BMI':BMI,
'Smoker':Smoker,
'Stroke':Stroke,
'HeartDiseaseorAttack':HeartDiseaseorAttack,
'PhysActivity':PhysActivity,
'Fruits':Fruits,
'Veggies':Veggies,
'HvyAlcoholConsump':HvyAlcoholConsump,
'AnyHealthcare':AnyHealthcare,
'NoDocbcCost':NoDocbcCost,
'GenHlth':GenHlth,
'MentHlth':MentHlth,
'PhysHlth':PhysHlth,
'DiffWalk':DiffWalk,
'Sex':Sex,
'Age':Age,
'Education':Education,
'Income':Income,
'BMI_Category':BMI_Category,
'Age_Group':Age_Group,
'BMI_PhysActivity':BMI_PhysActivity

            }])

            input_df = input_df[features]

            scaled = scaler.transform(input_df)

            st.session_state.prob = model.predict_proba(scaled)[0][1]
            # RULE ENGINE INPUT

            rule_data = {

            'Age':Age,
            'BMI':BMI,
            'HighBP':HighBP,
            'HighChol':HighChol,
            'Smoker':Smoker,
            'PhysActivity':PhysActivity,
            'Fruits':Fruits,
            'Veggies':Veggies,
            'HvyAlcoholConsump':HvyAlcoholConsump,
            'HeartDiseaseorAttack':HeartDiseaseorAttack,
            'Stroke':Stroke,
            'AnyHealthcare':AnyHealthcare,
            'NoDocbcCost':NoDocbcCost,
            'GenHlth':GenHlth,
            'MentHlth':MentHlth,
            'PhysHlth':PhysHlth,
            'DiffWalk':DiffWalk,
            'Education':Education,
            'Income':Income

            }

            rule_score,rule_prob,rule_explanations = run_rule_engine(rule_data)
            
            
            
            # ---------------- CLINICAL RECOMMENDATION ENGINE ---------------- #

            def generate_recommendations(data, final_prob):

                recs=[]

                if final_prob <0.30:

                    recs.append("Maintain healthy lifestyle")
                    recs.append("Continue regular exercise")
                    recs.append("Annual diabetes screening")

                elif final_prob <0.60:

                    recs.append("Increase physical activity to 150 min/week")

                    if data['BMI']>25:
                        recs.append("Weight reduction recommended")

                    if data['HighBP']==1:
                        recs.append("Monitor blood pressure regularly")

                    if data['HighChol']==1:
                        recs.append("Lipid profile testing recommended")

                    recs.append("HbA1c screening suggested")

                else:

                    recs.append("Clinical diabetes screening strongly recommended")

                    if data['BMI']>30:
                        recs.append("Structured weight loss program advised")

                    if data['PhysActivity']==0:
                        recs.append("Start supervised exercise program")

                    if data['GenHlth']>=4:
                        recs.append("Physician consultation recommended")

                    if data['NoDocbcCost']==1:
                        recs.append("Seek low-cost healthcare programs")

                    recs.append("Fasting glucose test advised")
                    recs.append("HbA1c test advised")

                # lifestyle personalization

                if data['Smoker']==1:
                    recs.append("Smoking cessation program advised")

                if data['HvyAlcoholConsump']==1:
                    recs.append("Reduce alcohol consumption")

                if data['Fruits']==0 or data['Veggies']==0:
                    recs.append("Increase fruit and vegetable intake")

                if data['MentHlth']>10:
                    recs.append("Mental wellness support recommended")

                return recs
            # ---------------- DOCTOR INTERPRETATION ENGINE ---------------- #

            def generate_doctor_summary(data, final_prob):

                if final_prob <0.30:

                    level="LOW RISK"

                    summary="""
            Patient currently shows low diabetes risk.
            Preventive lifestyle should be continued.
            Routine screening recommended.
            """

                elif final_prob <0.60:

                    level="MODERATE RISK"

                    summary="""
            Patient shows moderate diabetes risk.
            Lifestyle modification recommended.
            Periodic glucose monitoring advised.
            Preventive intervention may reduce progression risk.
            """

                else:

                    level="HIGH RISK"

                    summary="""
            Patient shows high diabetes risk.
            Clinical screening strongly advised.
            Medical consultation recommended.
            Early intervention may prevent disease onset.
            """

                return level,summary

            # HYBRID RISK (ML + RULE)

            final_prob = (st.session_state.prob*0.7)+(rule_prob*0.3)

            st.session_state.final_prob = final_prob

            st.session_state.rule_score = rule_score

            st.session_state.rule_explanations = rule_explanations
            
            recommendations = generate_recommendations(rule_data,final_prob)

            st.session_state.recommendations = recommendations
            
            # =================STORE DOCTOR SUMMARY ================= #

            risk_level,doctor_summary = generate_doctor_summary(rule_data,final_prob)

            st.session_state.risk_level = risk_level
            st.session_state.doctor_summary = doctor_summary
            
            # =================CALCULATE SCORES ================= #

            health_score = calculate_health_score(rule_data)
            severity = medical_severity(rule_data)
            drivers = personalized_drivers(rule_data)

            st.session_state.health_score = health_score
            st.session_state.severity = severity
            st.session_state.drivers = drivers
            st.session_state.prediction_done=True

        st.success("Prediction Complete")

        c1,c2,c3 = st.columns(3)

        with c1:

            st.metric("ML Risk %",
            f"{st.session_state.prob*100:.1f}%")

            st.metric("Hybrid Risk %",
            f"{st.session_state.final_prob*100:.1f}%")

        with c2:

            if st.session_state.prob <0.3:

                st.success("🟢 LOW")

            elif st.session_state.prob <0.6:

                st.warning("🟠 MODERATE")

            else:

                st.error("🔴 HIGH")

        with c3:

            st.metric("Threshold",
            f"{threshold:.2f}")

        fig = go.Figure(go.Indicator(

mode="gauge+number",

value=st.session_state.prob*100,

title={'text':"Risk Meter"},

gauge={

'axis':{'range':[0,100]},

'bar':{'color':"darkblue"},

'steps':[

{'range':[0,30],'color':"green"},

{'range':[30,60],'color':"orange"},

{'range':[60,100],'color':"red"}

]

}

))

        st.plotly_chart(fig,use_container_width=True)
        
        st.subheader("🧠 Rule Engine Explanation")
        
        st.write("Rule Score:",st.session_state.rule_score)

        for r in st.session_state.rule_explanations[:5]:

            st.write("•",r)
            
            
        st.subheader("🏥 Clinical Recommendations")

        for rec in st.session_state.recommendations[:8]:

            if st.session_state.final_prob <0.3:

                st.success(rec)

            elif st.session_state.final_prob <0.6:

                st.warning(rec)

            else:

                st.error(rec)    
        
        # =================DOCTOR PANEL ================= #

        st.subheader("👨‍⚕ AI Doctor Summary")
        st.info(st.session_state.risk_level)
        st.write(st.session_state.doctor_summary)


        # ================= RISK FACTORS ================= #

        st.subheader("📊 Key Patient Risk Factors")

        drivers_list=[]

        if BMI>30: drivers_list.append("Obesity risk")
        if HighBP==1: drivers_list.append("Hypertension")
        if HighChol==1: drivers_list.append("High cholesterol")
        if PhysActivity==0: drivers_list.append("Physical inactivity")
        if Smoker==1: drivers_list.append("Smoking risk")
        if GenHlth>=4: drivers_list.append("Poor general health")

        for d in drivers_list[:6]:
            st.write("•",d)


        # ================= LIFESTYLE SCORE ================= #

        st.subheader("❤️ Lifestyle Score")

        lifestyle_score = 100

        if Smoker==1: lifestyle_score -=20
        if HvyAlcoholConsump==1: lifestyle_score -=15
        if PhysActivity==0: lifestyle_score -=20
        if Fruits==0: lifestyle_score -=10
        if Veggies==0: lifestyle_score -=10

        st.metric("Lifestyle Score",lifestyle_score)


        # ================= HEALTH SCORE ================= #

        st.subheader("🧬 Patient Health Score")
        st.metric("Health Score",st.session_state.health_score)


        # ================= SEVERITY ================= #

        st.subheader("🏥 Medical Severity Index")
        st.metric("Severity Score",st.session_state.severity)


        # ================= PERSONALIZED DRIVERS ================= #

        st.subheader("🎯 Personalized Risk Drivers")

        for d in st.session_state.drivers[:6]:
            st.write("•",d[0],"-",d[1])


        # ================= RADAR ================= #

        st.subheader("📊 Patient Risk Radar")

        radar = go.Figure()

        radar.add_trace(go.Scatterpolar(
            r=[
                HighBP*5,
                HighChol*5,
                min(BMI/10,5),
                (1-PhysActivity)*5,
                Smoker*5
            ],
            theta=[
                "Blood Pressure",
                "Cholesterol",
                "BMI",
                "Activity Risk",
                "Smoking"
            ],
            fill='toself'
        ))

        radar.update_layout(
            polar=dict(radialaxis=dict(visible=True,range=[0,5]))
        )

        st.plotly_chart(radar)


        # ================= DOWNLOAD REPORT ================= #

        st.subheader("📄 Patient Report")

        report=f"""
        AI DIABETES RISK REPORT

        Risk Level: {st.session_state.risk_level}

        ML Risk:
        {st.session_state.prob*100:.1f}%

        Hybrid Risk:
        {st.session_state.final_prob*100:.1f}%

        Doctor Summary:
        {st.session_state.doctor_summary}

        Top Rule Findings:
        {st.session_state.rule_explanations[:5]}

        Recommendations:
        {st.session_state.recommendations[:6]}
        """

        st.download_button(
            "Download Report",
            report,
            file_name="diabetes_report.txt"
        )
        
# ---------------- TAB 2 ANALYTICS ---------------- #

with tab2:

    st.subheader("Probability Breakdown")

    if st.session_state.prediction_done:

        fig = px.bar(

        x=["No Diabetes","Diabetes"],

        y=[1-st.session_state.prob,
           st.session_state.prob],

        color=["No Diabetes","Diabetes"]

        )

        st.plotly_chart(fig)

    else:

        st.info("Run prediction first")


# ---------------- TAB 3 MODEL INSIGHTS ---------------- #

with tab3:

    st.subheader("Top Risk Drivers")

    fig = px.bar(

    importance.head(10),

    x="importance",

    y="feature",

    orientation='h'

    )

    st.plotly_chart(fig)

    if st.session_state.prediction_done:

        st.subheader("Key Contributors")

        top3 = importance.head(3)['feature'].tolist()

        st.write(top3)

    else:

        st.info("Run prediction first")


# ---------------- TAB 4 ABOUT ---------------- #

with tab4:

    st.write("""

AI Diabetes prediction system using RandomForest.

Built for preventive healthcare screening.

NOT a medical diagnosis.

""")


# ---------------- FOOTER ---------------- #

st.divider()

st.caption("⚠ Medical Disclaimer")

st.caption("Built using Streamlit + Scikit Learn")
